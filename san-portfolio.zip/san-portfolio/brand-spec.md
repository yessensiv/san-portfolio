# Nurdaulet Yessensary portfolio

Reference: https://curtisdesignr.me/, directly inspected 8–9 October 2026, plus the user’s desktop and phone recordings.

Keep the user’s name, NY initials, six GitHub projects and truthful project descriptions. Do not substitute the reference author’s identity or employment history.

## Visual measurements

Black #000; foreground #f5f0eb; green #9df133; tile #84c72f; tile stroke #599f00; purple #54339d; reveal band #8607ff (linear RGB output of the reference shader’s #C02DFF color); orange #f75049. Rajdhani headings, DM Sans body, DM Mono labels, locally served fonts. Header 76px, desktop inset 32px, phone inset 16px.

Desktop gallery uses the first six reference card positions, scaled by min((viewport height − 140)/786, 1). Horizontal choreography starts above 1024px. Tablet uses two columns; phone below 768px uses one column.

## Motion

Hero scroll phase 4.5 viewport heights. Quote decode runs for 700ms after crossing scroll thresholds. Pixel reveal starts at three viewport heights. Reversible masks use 16 columns, the reference sine noise and 60% directional weighting. Gallery handoff travels 1.34 viewport widths with quadratic easing and a damped scroll follow. Card reveals use 26px cells, 800ms duration, a two-stage image reveal and a solid purple band with scattered edges; they replay in reverse on re-entry. Cursor progress ring is 60px, with a 29.5px radius and 1px stroke. Reduced motion removes choreography.

The implementation recreates the behavior in native DOM/canvas. The original uses WebGL shaders; pixel-level equivalence of shader distortion is not established. Personal content necessarily changes text and imagery.

## Sound

Clean original background.mp3 at 30%, original hover/click WAVs at 50%. Start after the first interaction; SOUND controls all audio. Never use the screen-recording soundtrack: it includes notification sounds.

## Verification

Build validates local assets. Browser review covers desktop and phone layout, forward/reverse gallery scrolling, menu, /work navigation and playback continuity. No Git repository is initialized in this workspace; local changes are not pushed to GitHub.

## Handoff regression, 9 October 2026

Fixed a 0.34 × viewport-width gap between statistics and the incoming gallery. Both panels are one viewport wide, so their translations now share one offset and one adjoining edge. The 1.34 scroll-duration factor remains separate from their physical spacing.

Browser reproduction before the fix: 869.73px gap at 2559px width. After the fix, four forward and four reverse positions at that width have a 0.33px overlap from viewport rounding; the 1440px check has a 0.00006px gap. No console errors in the final browser check. The dark project selector no longer appears through the handoff.

## Interaction and exit regression, 9 October 2026

EXPLORE MORE was blocked by the parent section’s inert state while already visible. The incoming gallery is now interactive whenever it is visible. Verified a real click during the handoff at scroll 5624px: the hit target is the anchor, the parent is not inert, and navigation opens /work at scroll 0.

The exit mask now uses actual scroll position, matching the native sticky release. Horizontal gallery movement retains its damped follow. Before the 9031.76px boundary, the next section stays at y≈0; after it, the gallery is hidden and the next section moves with normal scroll. Verified forward positions 9010, 9082, 9154px and reverse positions 9082, 9010, 8938px. No console errors in the final check.

Selector interaction reference: 20261008-1923-09.0436185.mp4. Rows use 68px height, lime hover and white selected state. Project mark glitches for 650ms, then settles; descriptions decode over 700ms with reserved height. The completed gallery viewport and sequence no longer intercept selector clicks. Desktop layout uses 257px side columns and a 669:415 center frame; phone retains the project accordion.
