# Nurdaulet Yessensary — Portfolio

Personal portfolio based on the supplied screen recording of curtisdesignr.me, with Nurdaulet's name and five public GitHub projects.

## Run

Next.js 16 + React 19 + TypeScript + GSAP. Node.js 20.9 or newer. Install packages first with npm install.

```sh
npm run dev
```

Open http://127.0.0.1:3000. The complete project gallery is at /work.

## Build

```sh
npm run build
```

Production build lives in .next. Run npm start after building. Vercel is configured for Next.js. Both / and /work are served by the App Router.

## Edit

- index.html and work.html — shared personal content, navigation, and contacts.
- lib/projects.ts — typed project data; projects.js renders cards and selectors.
- reference.css — recording-based composition and responsive layout; overrides style.css.
- reference.js — project selection, halftone marks, hover quote, and mosaic page transitions.
- experience.js — NY animation, menu, text effects, and pinned horizontal gallery.
- sound.js — interface effects and saved mute preference.
- assets/previews — local static snapshots of DentaLux, Zaga Zaga, and the collaborative team project. Scripts are removed and previews are non-interactive.

The hero uses NY initials at the user's request. Flow uses its repository logo. ENT Math and DocMind use typographic covers. No employment history or client relationships are invented.

## Sound

Audio starts after the first click or keyboard interaction, as required by browsers. The clean original music track and hover/click effects are used. Screen-recording audio is excluded to prevent recorded notifications from playing. The sound control is available in the header on desktop and inside the menu on all screen sizes. Mute preference persists locally and effects pause in hidden tabs.

The additional desktop and phone recordings guided the responsive update: vertical phone galleries, an exclusive project accordion, a dark inset menu, and a loading percentage followed by a mosaic reveal.



Background music now uses the separate original music file assets/sound/background.mp3 at 30% volume, never the screen-recording soundtrack. It starts on the first user gesture and shares the SOUND toggle with interface effects.

Live-site calibration (9 October 2026) is documented in brand-spec.md. The final geometry and choreography overrides are motion.css and motion.js.

## Next.js runtime

app/layout.tsx and app/[[...route]]/page.tsx provide the server-rendered shell. app/portfolio-runtime.tsx is a typed client bridge that drives the existing canvas and scroll choreography with the GSAP ticker. scripts/prepare-next.mjs bundles existing interaction scripts and copies assets before development/build. The interaction modules remain JavaScript during this compatibility migration; the routes, project data and animation bridge use TypeScript. Run npm run typecheck to validate types.


